import {S3Client,GetObjectCommand} from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";

const s3Client = new S3Client({
    region: "eu-north-1",       
    credentials: {
        accessKeyId: "AKIA3CHRFTUHWUVKWLIK",
        secretAccessKey: "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",   // IAM user vineet1 with S3 access
    },
});


const getObjectUrl = async (bucketName, objectKey) => {
    try {
        const command = new GetObjectCommand({
        Bucket: "vineetsfirstbucket",
        Key: objectKey,
        });
        const SignedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 });
        return SignedUrl;
    } catch (error) {
        console.error("Error getting object from S3:", error);
        throw error;
    }
}


getObjectUrl("vineetsfirstbucket", "ChatGPT Image Mar 29, 2025, 03_23_20 PM.png").then((url) => {
    console.log("Signed URL:", url);
}).catch((error) => {
    console.error("Error:", error);
});